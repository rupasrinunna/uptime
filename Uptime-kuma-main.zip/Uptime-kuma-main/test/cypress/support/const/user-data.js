exports.DEFAULT_USER_DATA = {
    username: "testuser",
    password: "testuser123",
};
